We are using python 2.7.5

The libraries/versions used in this code are 
* numpy 1.13.3
* matplotlib 2.1.1
* sklearn 0.19.1
* nltk 3.2.5
* re 2.2.1
